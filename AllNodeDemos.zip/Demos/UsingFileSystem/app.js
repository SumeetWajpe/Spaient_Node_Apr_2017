﻿var fs = require('fs');

if (fs.existsSync('temp')) {
    console.log('Dir exists.. Removing..');  
    if (fs.existsSync('temp/new.txt')) {        
        fs.unlinkSync('temp/new.txt');   // removing the file !     
    }
    fs.rmdirSync('temp');
}

fs.mkdirSync('temp');

if (fs.existsSync('temp')) {
    process.chdir('temp');
    fs.writeFileSync('test.txt', 'This is some sample data to be written !');
    fs.renameSync('test.txt', 'new.txt');
    console.log('File has a size of : ' + fs.statSync('new.txt').size + " bytes !");
    console.log('File contents : ' + fs.readFileSync('new.txt').toString());
}
console.log('Program ended..');
