﻿var fs = require('fs');

fs.mkdir('temp', function (err) {
    if (err) {
        console.log('Error : ' + err)
    }
    else {
        fs.exists('temp', function (exists) {
            if (exists) {
                process.chdir('temp');
                fs.writeFile('test.txt', 'This is some sample data to be written !', function (err) {
                    fs.rename('test.txt', 'new.txt', function (err) {
                        console.log("Rename data : " + data);
                        fs.stat('new.txt', function (err, stats) {
                            console.log('File has a size of : ' + stats.size + " bytes !");
                            fs.readFile('new.txt', function (err,data) {
                                console.log('File contents : ' + data.toString());
                            });
                        });
                    });
                });
            }
        })
    }
});