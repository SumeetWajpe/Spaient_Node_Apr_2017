﻿var Add = function (x, y) {
    return x + y;
}
var Subtract = function (x, y) {
    return x - y;
}
var Product = function (x, y) {
    return x * y;
}


var PI = 3.14;

module.exports = {
    Addition: Add,
    Multiply: Product,
    PI: PI
};

//module.exports.Addition = Add;
//module.exports.Multiplication = Product;


