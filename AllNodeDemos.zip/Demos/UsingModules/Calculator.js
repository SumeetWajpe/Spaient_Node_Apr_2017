﻿// Client

//var mathLib = require('./MathLib').Addition;
var mathLib = require('./MathLib');

console.log("The addition is : " + mathLib.Addition(10, 20));
console.log("The difference is : " + mathLib.Subtract(10, 20));