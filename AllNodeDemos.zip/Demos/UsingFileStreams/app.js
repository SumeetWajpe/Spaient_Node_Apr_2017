﻿var fs = require('fs');

fs.readFile('Data.txt', function (err, dataFromTheFile) {
    if (err) {
        console.log('Error occurred : ' + err);
    }
    else {
        console.log('Reading (Async) Result : ' + dataFromTheFile);
    }
});