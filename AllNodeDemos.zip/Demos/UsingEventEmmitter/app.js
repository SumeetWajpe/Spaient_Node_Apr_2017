﻿var EventEmitter = require('events').EventEmitter;

var getResource = function (maxIteration){
    var e = new EventEmitter();
    // emit events here..
    process.nextTick(function () {
        var cnt = 0;
        e.emit('start'); // i am sure on('start') is registered !     

        var t = setInterval(function () {            
                 e.emit('data', ++cnt);  // emit data !
                
                if (cnt === 8) {
                    e.emit('error', cnt);
                    clearInterval(t);
                }                   
            
            if (cnt == maxIteration) {
                e.emit('done', cnt);
                clearInterval(t);
            }
        },1000)
    });    
    return e;
}

// Client 
var res = getResource(10);  // return an object of Event Emitter !

res.on('start', function () {
    console.log('Started..');
});

res.on('data', function (d) {
    console.log('I received : ' + d);
});

res.on('done', function (d) {
    console.log('I ended with count : ' + d);

});

res.on('error', function (d) {
    console.log('I ended with error count : ' + d);

});