﻿const http = require('http');
const socket = require('socket.io');
var fs = require('fs');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
fs.readFile(__dirname + '/Client.html', function (err, data) {
    if (err) {
        console.log(err)
    }
    else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        return res.end(data);
    }
});// end of readFile !
});

var io = socket.listen(server);

io.sockets.on('connection', function (skt) {
    setInterval(function () {
        var dataToBeSent = new Date();
        skt.emit('messageForClient', dataToBeSent);
    }, 2000);

    skt.on('messageFromClient', function (dataFromClient) {
        console.log('Data From client : ' + dataFromClient);
    });
});

server.listen(port, hostname, () => {
console.log(`Server running at http://${hostname}:${port}/`);
});