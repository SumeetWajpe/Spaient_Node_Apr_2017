﻿var request = require('request');
var fs = require('fs');

var s = request('http://www.google.com'); // returns an instance of EventEmitter !
var response = '';

s.on('data', function (chunkOfData) {
    //console.log('\n\n\n>>>>>>>>>>>>>>>>>>>>>>>>> Data  >>>>>>>>>>>>>>>>>>>>>>>>>\n\n\n' + chunkOfData);
    response += chunkOfData;   
});

s.on('end', function () {
    console.log('>>> DONE >>>');
    fs.writeFile('MyResponse.html', response);
})