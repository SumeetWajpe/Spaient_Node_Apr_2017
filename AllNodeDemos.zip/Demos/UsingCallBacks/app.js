﻿var maxTime = 1000;
var evenDoubler = function (n, callBack) {
    var waitTime = Math.floor(Math.random() * (maxTime + 1))
    if (n % 2) {
        setTimeout(function (){
            callBack(new Error('Odd input !'));
        }, waitTime)
    }
    else {
        setTimeout(function () {
            callBack(null, n * 2, waitTime);
        }, waitTime)
    }
}

var ProcessResult = function (err,results,time){
    if (err) {
        console.log('Error : ' + err.message);
    } else {
        console.log('Result : ' + results);
    }
}

evenDoubler(2, ProcessResult);
evenDoubler(3, ProcessResult);
evenDoubler(4, ProcessResult);

console.log('Program ended !');