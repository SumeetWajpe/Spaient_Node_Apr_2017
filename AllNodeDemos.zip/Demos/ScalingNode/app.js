﻿//var exec = require('child_process').exec;

//// 10000 lines of code !
//// retrun a stream !
//var child = exec('node -v', null, function (err, stdout, stderr) {

//    if (err) {
//        console.log('Error : ' + err);
//    }
//    else {
//        console.log('The result : ' + stdout);
//    }

//});

//exec('systeminfo',null, function (err, stdout, stderr) {
    
//    if (err) {
//        console.log('Error : ' + err);
//    }
//    else {
//        console.log('The result : ' + stdout);
//    }

//});

// for spawning a different process and return the output
//var childProcess = require('child_process');

//var workerProcess;

//for (var i = 0; i < 3; i++) {
//    workerProcess = childProcess.spawn('node', ['myModule', i]);
    
//    workerProcess.stdout.on('data', function (dataFromChildProcess) {
//        console.log('Std out : ' + dataFromChildProcess);
//    });  

//    workerProcess.on('close', function (code) {
//        console.log('Worker process exited with code ' + code);
//    });
//}


/// Use for for Creating a new v8 instance
//var childProcess = require('child_process');
//var workerProcess;

//for (var i = 0; i < 3; i++) {
//    workerProcess = childProcess.fork('myModule', [i]);
//}




