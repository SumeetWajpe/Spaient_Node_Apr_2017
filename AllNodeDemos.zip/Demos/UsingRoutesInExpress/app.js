﻿var express = require('express');
var bodyParser = require('body-parser');

var app = express();
var router = express.Router();

router.route('/products/:name').get(function (request, response) {
    var products = [
        { Name: 'Laptop', Price: 30000 },
        { Name: 'Mobile', Price: 10000 }
    ];
    
    var name = request.params.name;
    
    if (name) {
        response.json(products[0]);
        console.log(name);
    }
    else {
        response.json(products);
    }    
});

app.use('/data', router);
app.use(bodyParser.urlencoded(
    {extended:true}
));

app.get('/', function (request, response) {
    response.sendFile('Login.html', { root: __dirname });
   // response.setHeader('Allow-Control-Cross-Origin', '*');

});

app.post('/login', function (request, response) {
    // get the value from the client  -> request

    var uname = request.body.username;
    var pwd = request.body.password;
    console.log('The username :' + uname + " & password : " + pwd);
    response.setHeader("")
    response.send("success");
    //response.setHeader('Allow-Control-Cross-Origin', '*');
});


app.listen(4000, function () {
    console.log('Server running @ 4000 !')
});