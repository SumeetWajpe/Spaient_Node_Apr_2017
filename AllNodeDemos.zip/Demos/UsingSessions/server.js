﻿var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');



var app = express();
app.use(cookieParser());
app.use(session({
    secret: 'Create a unique Id',
    saveUninitialized: true,
    resave:true
}));
app.get('/', function (request, response) {
    
    response.send('This is sessions and Cookies Management');
    console.log('--------------------------------->>>>>>>>>>>-------------------');
    
    console.log(request.cookies);
    console.log(request.session);

    var sessionData = request.session;    
    sessionData.SomeSessionData = "Actual Value !"; // store !
    sessionData.save();
    //session["SomeSessionData"] = "Actual Value !";   // asp.net 
});

app.get('/getData', function (req,res){
    console.log(req.session.SomeSessionData);
    res.send('Session data read !');
})

app.listen(4000, function () {
    console.log('Server running @ 4000 !')
});