﻿var buff = new Buffer('sample data for buffer more data !');
//console.log(buff);   // bytes

console.log(buff.toString());
console.log(buff.toString('utf-8'));
console.log(buff.toString('base64'));

console.log(buff.length);

var buffOne = new Buffer(250);// length
var len= buffOne.write('Hello !');
console.log('No of Bytes written : ' + len);
console.log('Total size : ' + buffOne.length);


var buffer1 = new Buffer('This is first line of string !');
var buffer2 = new Buffer('This is second line of string !');
var buffer3 = Buffer.concat([buffer1, buffer2]);
console.log(buffer3.toString());


