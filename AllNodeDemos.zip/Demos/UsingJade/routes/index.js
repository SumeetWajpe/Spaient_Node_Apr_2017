﻿var express = require('express');
var router = express.Router();
router.get('/', function (req, res) {
    //res.send('Route working !');
    // send the jade file !
    res.render('index', {     
        data: ' Jade Using Blocks !',
        msg: 'This is displayed using Dynamic Data',
        users: [
            { name: 'Sumeet' }
            , { name: 'Tejas' }
            , { name: 'Abhijeet' }
        ]   
    });
});

module.exports = router;module.exports = router;