﻿var express = require('express');
var routes = require('./routes/index');
var path = require('path');
var app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use('/', routes);

app.listen(4000, function () {
    console.log('Server running @ 4000 !')
});