﻿const http = require('http');
var fs = require('fs');
const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
//res.statusCode = 200;
//res.setHeader('Content-Type', 'text/html');
//res.end('<h1>Hello World</h1>');
   fs.readFile(__dirname + '/AboutUs.html', function (err,data) {
    if (err) {
                console.log(err)
    }
    else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        return res.end(data);
    }
        });// end of readFile !
});

server.listen(port, hostname, () => {
console.log(`Server running at http://${hostname}:${port}/`);
});