﻿var nettcp = require('net');
var fs = require('fs');
var writableLog = fs.createWriteStream('Logs.txt');

var server = nettcp.createServer(function (connect) {

    console.log('Connection established....');
    connect.on('end', function () {
        console.log('Connection terminated....');
    });
    connect.write('Some default message here..\r\n');

    //connect.on('data', function (chunk) {
    //    if (chunk.toString() == '\r\n' ) {
    //        connect.pipe(connect).pipe(writableLog);
    //    }
    //});

    connect.pipe(connect).pipe(writableLog);
});

server.listen(6565, function () {
    console.log('Server listening @ 6565 !');
});